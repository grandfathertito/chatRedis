<?php
return [
    'success_login' => 'Success Login',
    'Invalid credentials' => 'Invalid credentials',
    'Success Register' => 'Success Register',
    'Could not create token' => 'Could not create token',
    'Successfully logged out' => 'Successfully logged out',
    'Invalid Token' => 'Invalid Token',
    'Send Was Success' => 'Message Was Send Success',
];
